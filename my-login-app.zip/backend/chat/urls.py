# chat/urls.py
from django.urls import path
from .views import LoginView, SignupView, FileUploadView, ConversationView

urlpatterns = [
    path('login/', LoginView.as_view(), name='login'),
    path('signup/', SignupView.as_view(), name='signup'),  # New signup endpoint
    path('api/document/upload/', FileUploadView.as_view(), name='upload_document'),
    # path('api/chat/history/', views.get_chat_history, name='chat_history'),
    path('api/conversation/start/', ConversationView.as_view(), name='start_conversation'),
    # path('api/conversation/continue/', views.continue_conversation, name='continue_conversation'),
]
