# chat/models.py
from django.db import models
from django.contrib.auth.models import User

class File(models.Model):
    file_id = models.AutoField(primary_key=True)
    filename = models.CharField(max_length=255)
    filepath = models.CharField(max_length=255)
    upload_date = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='files')

class Conversation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='conversations')
    message = models.TextField()
    response = models.TextField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
