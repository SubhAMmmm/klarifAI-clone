// /* eslint-disable no-unused-vars */
// import React from 'react';
// import { Paperclip, Send } from 'lucide-react';

// const MainContent = () => {
//   return (
//     <>
//     <main className="flex-1 p-5">
//       <div className="text-center max-w-4xl mx-auto mt-8">
//         <div className="bg-black p-5 rounded-lg shadow-lg mx-auto max-w-2xl mb-8">
//           <h1 className="text-white text-3xl font-bold">Welcome to Klarifai</h1>
//         </div>

//         <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8 px-4">
//           {['2024 Consumer Trends', 'Purchase Considerations', 'Category Consumption'].map((prompt, index) => (
//             <button 
//               key={index}
//               className="bg-[#414141] text-white p-6 rounded-lg hover:bg-gradient-to-r hover:from-[#3344dc] hover:to-[#5ff2b6] transition-all duration-200 transform hover:scale-105"
//             >
//               {prompt}
//             </button>
//           ))}
//         </div>

//         <div className="text-left mt-9 px-4">
//           <h3 className="bg-gradient-to-r from-[#3e6fd3] to-[#60f6b5] text-transparent bg-clip-text font-bold text-4xl">
//             Hello, John Doe!
//           </h3>
//           <h4 className="text-gray-400 mt-4 text-2xl">How Can I Help You Today?</h4>
//         </div>

//         {/* Search Box */}
//         <div className="mt-8 px-4">
//           <div className="relative max-w-3xl mx-auto">
//             <div className="flex items-center bg-[#414141] rounded-lg p-2">
//               <button className="text-gray-400 hover:text-white transition-colors">
//                 <Paperclip className="h-6 w-6" />
//               </button>
//               <input
//                 type="text"
//                 placeholder="Type your message here..."
//                 className="flex-1 bg-transparent border-none focus:outline-none text-white px-4"
//               />
//               <button className="bg-gradient-to-r from-[#3344dc] to-[#5ff2b6] text-white px-6 py-2 rounded-lg hover:opacity-90 transition-opacity">
//                 <Send className="h-5 w-5" />
//               </button>
//             </div>
//           </div>
//         </div>
//       </div>
//     </main>
//     </>
//   );
// };

// export default MainContent;

/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import { Paperclip, Send } from 'lucide-react';
import { documentService } from '../../utils/axiosConfig';
import { toast } from 'react-toastify';
const [summary, setSummary] = useState('');
const [followUpQuestions, setFollowUpQuestions] = useState([]);

const MainContent = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) {
      toast.error('Please select a document to upload.');
      return;
    }

    try {
      const response = await documentService.uploadDocument(file);
      console.log('Upload response:', response.data);
      toast.success('Document uploaded successfully!');
      // Handle the response to display the summary and follow-up questions
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload document.');
    }
  };

  const handleMessageChange = (event) => {
    setMessage(event.target.value);
  };

  const handleSendMessage = async () => {
    if (!message) {
      toast.error('Please type a message.');
      return;
    }

    try {
      const response = await chatService.sendMessage(message);
      console.log('Chat response:', response.data);
      // Handle the response to display the answer
      setMessage('');
    } catch (error) {
      console.error('Chat error:', error);
      toast.error('Failed to send message.');
    }

    try {
      const response = await documentService.uploadDocument(file);
      console.log('Upload response:', response.data);
      setSummary(response.data.documents[0].summary);
      setFollowUpQuestions(response.data.documents[0].follow_up_questions);
      toast.success('Document uploaded successfully!');
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload document.');
    }
  };

  return (
    <main className="flex-1 p-5">
      <div className="text-center max-w-4xl mx-auto mt-8">
        <div className="bg-black p-5 rounded-lg shadow-lg mx-auto max-w-2xl mb-8">
          <h1 className="text-white text-3xl font-bold">Welcome to Klarifai</h1>
        </div>

        <div className="mt-8 px-4">
          <input type="file" onChange={handleFileChange} />
          <button onClick={handleUpload} className="bg-gradient-to-r from-[#3344dc] to-[#5ff2b6] text-white px-6 py-2 rounded-lg hover:opacity-90 transition-opacity">
            Upload Document
          </button>
        </div>

        <div className="mt-8 px-4">
          <div className="relative max-w-3xl mx-auto">
            <div className="flex items-center bg-[#414141] rounded-lg p-2">
              <input
                type="text"
                placeholder="Type your message here..."
                value={message}
                onChange={handleMessageChange}
                className="flex-1 bg-transparent border-none focus:outline-none text-white px-4"
              />
              <button onClick={handleSendMessage} className="bg-gradient-to-r from-[#3344dc] to-[#5ff2b6] text-white px-6 py-2 rounded-lg hover:opacity-90 transition-opacity">
                <Send className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default MainContent;