// /* eslint-disable no-unused-vars */
// import React from 'react';
// import { Settings, CircleHelp, Plus, ChevronDown } from 'lucide-react';

// const Sidebar = ({ isOpen }) => {
//   return (
//     <>
//     <aside className={`${isOpen ? 'w-1/4' : 'w-0'} bg-[#46464673] text-white transition-all duration-300 overflow-y-auto rounded-tr-lg rounded-br-lg min-h-[85vh] relative`}>
//       <div className="p-4">
//         <div className="mb-4">
//           <span className="text-white">Consumer</span>
//           <p>Consumer Trends</p>
//           <div className="my-4">
//             <span className="text-[#d6292c] font-semibold text-lg bg-white p-2 rounded px-9 flex items-center gap-2">
//               <Plus size={20} /> 
//               New Chat
//             </span>
//           </div>
          
//           <div className="mt-4">
//             <h6 className="text-white mb-2">Recent Chats</h6>
//             <div className="space-y-2">
//               <div className="flex justify-between items-center group">
//                 <span>2024 Consumer Trends</span>
//                 <ChevronDown className="h-4 w-4 opacity-0 group-hover:opacity-100" />
//               </div>
//             </div>
//           </div>
//         </div>

//         <div className="border-t border-gray-600 pt-4">
//           <div className="space-y-3">
//             <button className="text-white w-full text-left flex items-center gap-2">
//               <Settings size={20} />
//               Settings
//             </button>
//             <button className="text-white w-full text-left flex items-center gap-2">
//               <CircleHelp size={20} />
//               Help
//             </button>
//           </div>
//         </div>
//       </div>
//     </aside>
//     </>
//   );
// };

// export default Sidebar;


/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import { Settings, CircleHelp, Plus, ChevronDown } from 'lucide-react';
import { documentService } from '../../utils/axiosConfig';
import { toast } from 'react-toastify';

const Sidebar = ({ isOpen }) => {
  const [chatHistory, setChatHistory] = useState([]);

  useEffect(() => {
    const fetchChatHistory = async () => {
      try {
        const response = await documentService.getChatHistory();
        
        // Log the response for debugging
        console.log('Chat History Response:', response);

        setChatHistory(response.data || []);
      } catch (error) {
        console.error('Failed to fetch chat history', error);
        toast.error('Failed to load chat history');

        // Log detailed error information
        if (error.response) {
          console.error('Error Response:', error.response.data);
          console.error('Error Status:', error.response.status);
        }
      }
    };

    fetchChatHistory();
  }, []);

  return (
    <aside className={`${isOpen ? 'w-1/4' : 'w-0'} bg-[#46464673] text-white transition-all duration-300 overflow-y-auto rounded-tr-lg rounded-br-lg min-h-[85vh] relative`}>
       <div className="p-4">
        <div className="mb-4">
          <span className="text-white">Consumer</span>
          <p>Consumer Trends</p>
          <div className="my-4">
            <span className="text-[#d6292c] font-semibold text-lg bg-white p-2 rounded px-9 flex items-center gap-2">
              <Plus size={20} /> 
              New Chat
            </span>
          </div>
          
          <div className="mt-4">
            <h6 className="text-white mb-2">Recent Chats</h6>
            <div className="space-y-2">
              {chatHistory.map((chat, index) => (
                <div key={index} className="flex justify-between items-center group">
                  <span>{chat.title}</span>
                  <ChevronDown className="h-4 w-4 opacity-0 group-hover:opacity-100" />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-gray-600 pt-4">
          <div className="space-y-3">
            <button className="text-white w-full text-left flex items-center gap-2">
              <Settings size={20} />
              Settings
            </button>
            <button className="text-white w-full text-left flex items-center gap-2">
              <CircleHelp size={20} />
              Help
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;