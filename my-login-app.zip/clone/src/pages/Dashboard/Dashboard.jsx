/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import Header from '../../components/dashboard/Header';
import Sidebar from '../../components/dashboard/Sidebar';
import MainContent from '../../components/dashboard/MainContent';
import Footer from '../../components/dashboard/Footer';

const Dashboard = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <>
    <div className='p-0'>
    <div className="flex flex-col min-h-screen bg-[#303030] ">
      <Header />
      <div className="flex">
        <Sidebar isOpen={isSidebarOpen} />
        <MainContent />
      </div>
      <Footer />
    </div>
    </div>
    </>
  );
};

export default Dashboard;