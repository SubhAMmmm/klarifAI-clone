// import axios from 'axios';

// const axiosInstance = axios.create({
//   baseURL: 'http://localhost:8000/api', // Your Django backend URL
//   headers: {
//     'Content-Type': 'application/json',
//     'Accept': 'application/json',
//   },
// });

// // Optional: Add request interceptor for adding auth token
// axiosInstance.interceptors.request.use(
//   (config) => {
//     const token = localStorage.getItem('token');
//     if (token) {
//       config.headers['Authorization'] = `Token ${token}`;
//     }
//     return config;
//   },
//   (error) => Promise.reject(error)
// );

// //landing page
// // Document and Chat Services
// export const documentService = {
//     uploadDocument: (file) => {
//       const formData = new FormData();
//       formData.append('document', file);
//       return axiosInstance.post('/upload-document/', formData, {
//         headers: { 'Content-Type': 'multipart/form-data' }
//       });
//     },
  
//     getChatHistory: () => {
//       return axiosInstance.get('/chat-history/');
//     }
//   };
  
//   export const chatService = {
//     startConversation: (documentId, message) => {
//       return axiosInstance.post('/start-conversation/', {
//         document_id: documentId,
//         message: message
//       });
//     },
  
//     continueConversation: (conversationId, message) => {
//       return axiosInstance.post('/continue-conversation/', {
//         conversation_id: conversationId,
//         message: message
//       });
//     }
//   };
  
//   export default axiosInstance;


// ############################################################
// src/utils/axiosConfig.js
// import axios from 'axios';

// const axiosInstance = axios.create({
//   baseURL: 'http://localhost:8000/api', // Your Django backend URL
//   headers: {
//     'Content-Type': 'application/json',
//     'Accept': 'application/json',
//   },
// });

// // Add request interceptor for adding auth token
// axiosInstance.interceptors.request.use(
//   (config) => {
//     const token = localStorage.getItem('token');
//     if (token) {
//       config.headers['Authorization'] = `Token ${token}`;
//     }
//     return config;
//   },
//   (error) => Promise.reject(error)
// );

// // Export services
// export const documentService = {
//   uploadDocument: (file) => {
//     const formData = new FormData();
//     formData.append('document', file);
//     return axiosInstance.post('/document/upload/', formData, {
//       headers: { 'Content-Type': 'multipart/form-data' }
//     });
//   },

//   getChatHistory: () => {
//     return axiosInstance.get('/chat/history/');
//   }
// };

// export const chatService = {
//   startConversation: (documentId, message) => {
//     return axiosInstance.post('/conversation/start/', {
//       document_id: documentId,
//       message: message
//     });
//   },

//   continueConversation: (conversationId, message) => {
//     return axiosInstance.post('/conversation/continue/', {
//       conversation_id: conversationId,
//       message: message
//     });
//   }
// };

// export default axiosInstance;


// ############################################################

import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'http://localhost:8000/api', // Your Django backend URL
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

// Add request interceptor for adding auth token
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Token ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Export services
export const documentService = {
  uploadDocument: (file) => {
    const formData = new FormData();
    formData.append('files', file); // Ensure 'files' matches your Django view
    return axiosInstance.post('/document/upload/', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },

  getChatHistory: () => {
    return axiosInstance.get('/chat/history/');
  }
};

export const chatService = {
  sendMessage: (message) => {
    return axiosInstance.post('/chat/', { message });
  }
};

export default axiosInstance;